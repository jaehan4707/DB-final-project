<?php               
    require_once 'dbconfig_project.php';
?>
<p><h3> 추가된 강좌 정보</h3></p>
<table class="table table-striped">
    <?php
    	// safely get input parameter 학번과 과목코드를 입력함.
    	$student_id = mysqli_real_escape_string($link, $_REQUEST['student_id']);
		$ccode=mysqli_real_escape_string($link,$_REQUEST['ccode']);
	    // check input
		if (empty($student_id) || empty($ccode)) {
			print "Empty input not allowed.";
			exit;
		}		
		$sql = "INSERT INTO register(snum,stuno) values('$ccode','$student_id')";
        $result = mysqli_query($link, $sql);
		#triger 검사. 하나의 trigger에 걸린다면 종료
		if(mysqli_errno($link)==1452){ //1644
			print "해당 학번의 학생이 없거나 해당 과목은 2022년 2학기 글로벌SW융합전공 개설 과목이 아닙니다.";
			mysqli_close($link);
			exit(1);
		}
		if(mysqli_errno($link)==1644){ //1644
			print "제한사항(트리거)에 의해 수강꾸러미에 담는 것이 거절됩니다.";
			mysqli_close($link);
			exit(1);
		}
		#해당 학생이 이미 입력한 과목 코드를 수강한다면 종료
		if(mysqli_errno($link)==1062){
			echo "학번이 {$student_id}인 학생은 과목코드가 {$ccode}인 과목을  이미 담았습니다.<br><hr>";
			mysqli_close($link);
			exit(1);
		}
		#입력한 과목코드가 아니고 제한사항에 걸리지 않는다면 수강신청한 과목 정보 출력
        else{
		$Sql = "SELECT snum,subname,stuno,sname from register,subject,student 
		where '$ccode'=subject.subnum and '$student_id'=student.snumber
		and subject.subnum = register.snum and student.snumber = register.stuno";
		$Result = mysqli_query($link,$Sql);
		$row = mysqli_fetch_array($Result);
		print "<tr><td>" . $row['stuno'] . "</td><td>" . $row['sname'] . "</td><td>" .$row['snum'] ."</td><td>" .$row['subname'] . "</tr>";
		$count = 1;
	}
		mysqli_close($link);
    ?>
</table>