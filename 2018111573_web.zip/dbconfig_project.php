<?php
    $link = mysqli_connect("localhost","jaehan","7204","project");

    if($link==false){
        die("ERROR : Could not connect. " .mysqli_connect_error());
    
    }
?>