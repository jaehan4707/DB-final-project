<?php               
    require_once 'dbconfig_project.php';
?>
<p><h3> 삭제된 강좌 정보</h3></p>
<table class="table table-striped">
    <?php	
    	$student_id = mysqli_real_escape_string($link, $_REQUEST['student_id']);
		$ccode=mysqli_real_escape_string($link,$_REQUEST['ccode']);
	    // check input
		if (empty($student_id) || empty($ccode)) {
			print "Empty input not allowed.";
			exit;
		}
        //delete문
		$sql = "INSERT INTO register(snum,stuno) values('$ccode','$student_id')";
        $result = mysqli_query($link, $sql);
		if(mysqli_errno($link)==1062){ //만약 입력된 SSN과 과목코드라면 오류 출력하고 종료.
			echo "학번이 {$student_id}인 학생의 수강꾸러미에는 과목코드가 {$ccode}인 과목이 존재합니다.<br><hr>";
		}
		else{
			echo "학번이 {$student_id}인 학생의 수강꾸러미에는 과목코드가 {$ccode}인 과목이 존재하지않습니다.<br><hr>";
			mysqli_close($link);
			exit(1);
		}
		//else문에 걸리지 않는다면 해당 학생의 수강꾸러미에는 과목코드가 존재하기에 지워준다.
		$Sql = "delete from register where '$student_id' = register.stuno and '$ccode'=register.snum";
        $Result = mysqli_query($link, $Sql);
		$count = 1;
		echo "성공적으로 {$ccode}는 삭제되었습니다";
		mysqli_close($link);
    ?>
</table>